# aal-substringsbrute
longest common substrings

Program wyszukuje najdłuższe wspólne podciągi dwóch dowolnych ciągów, które potrafi generować automatycznie.
Dane wejściowe tworzone są automatycznie, lub mogą zostać utworzone przez użytkownika w formacie x aaa bbb, gdzie x - ilość znaków którymi mogą różnić się ciągi, aaa i bbb - ciągi.
Program najlepiej radzi sobie z problemami wielkości kilkunastu/kilkudziesięciu tysięci.

Do działania programu niezbędne jest zainstalowanie 'texttable', czego można dokonać przy użyciu komnendy: pip install texttable